/*
    Fingerpori widget - Fetches Fingerpori comic strip
    from <http://www.hs.fi/>
    
    --Mursu 

    Fingerpori widget is distributed in the hope that it will
    be useful, but WITHOUT ANY WARRANTY; without even the implied
    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

*/

widget.onshow = onshow;
var prev_url, next_url;

function onshow() {
    load_comic("http://www.hs.fi/fingerpori/");
}

function load_comic(strip_url) {
    $.get(strip_url, null, parse_data);
}

function parse_data(data) {
    current_img_url = $(data).find("div.strip > img").attr("src");
    prev_url = $(data).find("div.previous > a").attr("href");
    next_url = $(data).find("div.next > a").attr("href");
    
    $("#fingerpori").attr("src", current_img_url);

    //Check if previous comics exist and hide controls if not
    if (prev_url) {
        $("#previous").off("click");
        $("#previous").on("click", function() { load_comic(prev_url); });
        $("#previous").show();
    } else {
        $("#previous").off("click");
        $("#previous").hide();
    }
    if (next_url) {
        $("#next").off("click");
        $("#next").on("click", function() { load_comic(next_url); });
        $("#next").show();
    } else {
        $("#next").off("click");
        $("#next").hide();
    }
}

